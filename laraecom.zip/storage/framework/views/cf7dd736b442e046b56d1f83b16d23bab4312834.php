<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('extra-css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="breadcrumbs">
        <div class="container">
            <a href="/">Home</a>
            <i class="fa fa-chevron-right breadcrumb-separator"></i>
            <a href="<?php echo e(route('shop.index')); ?>">Shop</a>
            <i class="fa fa-chevron-right breadcrumb-separator"></i>
            <span>Macbook Pro</span>
        </div>
    </div> <!-- end breadcrumbs -->

    <div class="product-section container">
        <div>
          <div class="product-section-image">
              <img src="<?php echo e(productImage($product->image)); ?>" class="active" alt="product" id="currentImage">
              <!-- <img src="<?php echo e(asset('img/products/'.$product->slug.'.jpg')); ?>" alt="product"> -->
          </div>
          <div class="product-section-images">

            <!-- <div class="product-section-thumbnail selected">
              <img src="<?php echo e(asset('img/products/laptop-1.jpg')); ?>" alt="product">
            </div>
             -->
             <div class="product-section-thumbnail selected">
               <img src="<?php echo e(productImage($product->image)); ?>" alt="product">
             </div>
              <?php if($product->images): ?>
                <?php $__currentLoopData = json_decode($product->images,true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="product-section-thumbnail">

                    <img src="<?php echo e(productImage($image)); ?>" alt="product">
                  </div>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          </div>

        </div>
        <div class="product-section-information">
            <h1 class="product-section-title"><?php echo e($product->name); ?></h1>
            <div class="product-section-subtitle"><?php echo e($product->details); ?></div>
            <div class="product-section-price">$<?php echo e($product->price/100); ?></div>

            <p>
                <?php echo $product->description; ?>

            </p>

            <p>&nbsp;</p>

            <!-- <a href="#" class="button">Add to Cart</a> -->
            <form class="" action="<?php echo e(route('cart.store')); ?>" method="post">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
              <input type="hidden" name="name" value="<?php echo e($product->name); ?>">
              <input type="hidden" name="price" value="<?php echo e($product->price); ?>">
              <button class="button button-plain" type="submit" name="button">Add To Cart</button>

            </form>
        </div>
    </div> <!-- end product-section -->

    <?php echo $__env->make('partials.might-like', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
  <script>
    (function (){
        const currentImage = document.querySelector('#currentImage');
        const images = document.querySelectorAll('.product-section-thumbnail');
        images.forEach((element)=> element.addEventListener('click', thumbnailClick));
        function thumbnailClick(e) {

          currentImage.classList.remove('active');

          currentImage.addEventListener('transitionend',()=> {
          currentImage.src = this.querySelector('img').src;
          currentImage.classList.add('active');
          });

          images.forEach((element)=> element.classList.remove('selected'));
          this.classList.add('selected');
        }

    })();

  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laraecom\resources\views/product.blade.php ENDPATH**/ ?>