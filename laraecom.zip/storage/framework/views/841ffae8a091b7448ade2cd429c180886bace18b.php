<footer>
    <div class="footer-content container">
        <div class="made-with">Made with <i class="fa fa-heart heart"></i> by Kebir Youcef </div>
        <?php echo e(menu('footer','partials.menus.footer')); ?>

    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\laraecom\resources\views/partials/footer.blade.php ENDPATH**/ ?>