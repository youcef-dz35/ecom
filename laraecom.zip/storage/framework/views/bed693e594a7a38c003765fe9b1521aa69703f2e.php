
<ul>
  <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
      <?php if($menu_item->title=='Follow Me:'): ?>
        <li><?php echo e($menu_item->title); ?></li>
      <?php endif; ?>
      <a href="<?php echo e($menu_item->link()); ?>"> <i class="fa <?php echo e($menu_item->title); ?>"></i> </a>

    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<!-- <ul>
    <li>Follow Me: </li>

    <li><a href="https://www.facebook.com/youce.kebir"><i class="fa fa-facebook"></i></a></li>
    <li><a href="https://github.com/youcef-dz35"><i class="fa fa-github"></i></a></li>
    <li><a href="https://twitter.com/drehimself"><i class="fa fa-twitter"></i></a></li>
</ul> -->
<?php /**PATH C:\xampp\htdocs\laraecom\resources\views/partials/menus/footer.blade.php ENDPATH**/ ?>